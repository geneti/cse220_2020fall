#include <stdio.h>

int main() {
    int count = 0;
    while (1) {
        printf("Can't stop me now!!");
        printf(" %d\n", count);
        ++count;
    }
    return 0;
}

#include <stdio.h>
#include <stdbool.h>

int main(void) {
    return 0;
}

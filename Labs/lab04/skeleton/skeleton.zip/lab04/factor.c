#include <stdio.h>
int main(void) {
    printf("Give me a number to factor:\n");
    return 0;
}

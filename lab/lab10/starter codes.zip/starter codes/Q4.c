#include <stdio.h>
#include <string.h>

void strlow(char a[], int n) {
    // finish your code here
}

void main(){
    char a[] = "AbcDe";
    int n = 5;
    strlow(a, n);
    printf("%s\n", a);
}
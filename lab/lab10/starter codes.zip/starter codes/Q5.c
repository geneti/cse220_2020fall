#include <stdio.h>
#include <string.h>

int squared_euclidean(int a[], int b[], int n){
    // finish your code here
}

int main(){
    int n = 3;
    int a[] = {1,2,3};
    int b[] = {4,5,6};
    int total = squared_euclidean(a, b, n);
    printf("%d\n", total);
    return 0;
}
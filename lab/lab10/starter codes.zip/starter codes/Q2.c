#include <stdio.h>
#include <string.h>

// finish your code for find_max function
int find_max(     ) {
	
}

int main() {
	int a[] = {6,2,7,1};
	int n = 4;
	// find your code for the next line
	int max = find_max(     );
	printf("The maximum integer is: %d\n", max);
}
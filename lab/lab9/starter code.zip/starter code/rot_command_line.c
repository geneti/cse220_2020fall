#include <stdio.h>
#define MAX_STRING_LENGTH 100

int main(int argc, char * argv[]) {

	return 0;
}
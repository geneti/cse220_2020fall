#include <stdio.h>
#define MAX_STRING_LENGTH 100

int main(void) {

	return 0;
}
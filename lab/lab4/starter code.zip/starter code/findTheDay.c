#include <stdio.h>
int main(void) {
    printf("Enter your birthdate in mm/dd/yyyy format:\n");
}

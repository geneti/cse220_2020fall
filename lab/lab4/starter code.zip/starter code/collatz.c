#include <stdio.h>
int main(void) {
    printf("Give me a number to start:\n");
    return 0;
}
